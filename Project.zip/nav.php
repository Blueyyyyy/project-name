<h1>Police Emergency Service System</h1>

	<nav id="HeaderStyle">
		<a href="logcall.php"><span>Log Call</span></a>
		
		<a href="Update.php"><span>Update</span></a>
		
		<a href="#"><span>Report</span></a>
		
		<a href="#"><span>History</span></a>
	</nav>