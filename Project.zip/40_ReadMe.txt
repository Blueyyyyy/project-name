How to load the "pessdb.sql" into phpmyadmin.
Steps:
1 - If "pessdb" database does not exists in phpmyadmin, then create "pessdb" database.
2 - Once "pessdb" database is created, import "pessdb.sql" -> Press "Go".
3 - The datatables and values will be loaded within.